# OneDark Pro
QtCreator Syntax Color Theme inspired by OneDark Atom theme and OneDark Pro VSCode Theme.

# Support
If you like this theme, you can use it for free appreciate your support to have more themes :)

<a href="https://www.buymeacoffee.com/foxoman" rel="Support">![Support](https://www.buymeacoffee.com/assets/img/custom_images/black_img.png)</a>

* * *
# Screenshots

### Qt C++
![Qt](https://raw.githubusercontent.com/foxoman/onedarkpro/master/onedarkPro.png)

# Install

## Windows
`xcopy onedarkpro.xml %APPDATA%\QtProject\qtcreator\styles`

## MacOS
`cp onedarkpro.xml ~/.config/QtProject/qtcreator/styles/`

## Linux
`cp onedarkpro.xml ~/.config/QtProject/qtcreator/styles/`


